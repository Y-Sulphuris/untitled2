import './App.css';

import React, { useState } from 'react';

function ProductItem({ product, onIncrement, onDecrement, onRemove }) {
    return (
        <div
            style={{
                border: '1px solid #ccc',
                padding: '10px',
                margin: '10px',
                borderRadius: '5px',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'column',
            }}
            onDoubleClick={() => onRemove(product.id)}
        >
            <h3>{product.name}</h3>
            <p><strong>Price:</strong> {product.price}</p>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <button onClick={() => onDecrement(product.id)}>-</button>
                <span><strong>{product.count}</strong></span>
                <button onClick={() => onIncrement(product.id)}>+</button>
            </div>
        </div>
    );
}

function App() {
    const initialData = [
        {id: 1, name: 'Велосипед', price: 1000, count: 1},
        {id: 2, name: 'Самокат', price: 700, count: 1},
        {id: 3, name: 'Самолёт (если я его добуду)', price: 200000, count: 4}
    ];

    const [products, setProducts] = useState(initialData);

    function addProduct() {
        const input = prompt('Введите новый товар: (название и цену через пробел)');
        if (input) {
            const [name, price] = input.split(' ');
            const newProduct = {
                id: Date.now(),
                name: name,
                price: parseInt(price),
                count: 1
            };
            setProducts([...products, newProduct]);
        }
    }

    function handleIncrement(id) {
        setProducts(products.map(product => {
            if (product.id === id && product.count < 25) {
                return { ...product, count: product.count + 1 };
            }
            return product;
        }));
    }

    function handleDecrement(id) {
        setProducts(products.map(product => {
            if (product.id === id) {
                const newCount = product.count - 1;
                if (newCount === 0) {
                    setTimeout(() => {
                        setProducts(products.filter(p => p.id !== id));
                    }, 0);
                }
                return { ...product, count: newCount };
            }
            return product;
        }));
    }

    function handleRemove(id) {
        setProducts(products.filter(product => product.id !== id));
    }

    return (
        <div style={{
            padding: '20px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            flexDirection: 'column',
        }}>
            <h1>Список товаров</h1>
            <button
                onClick={addProduct}
                style={{
                    padding: '10px 15px',
                    backgroundColor: '#4cafa3',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    marginBottom: '20px'
                }}
            >
                Добавить товар
            </button>

            <div>
                {products.map(product => (
                    <ProductItem
                        key={product.id}
                        product={product}
                        onIncrement={handleIncrement}
                        onDecrement={handleDecrement}
                        onRemove={handleRemove}
                    />
                ))}
            </div>
        </div>
    );
}

export default App;
